package NFLDraft;



import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class NFLGUI extends Application {
    
    Stage primaryStage; 
    
    @Override     
    public void start(Stage primaryStage) {
        
        this.primaryStage = primaryStage; // use at the end of each scene to set the primaryStage each time a MOUSE Event happens
        
        Image broncosImg = new Image(getClass().getResourceAsStream("file:Broncos.png"));
        Button btn = new Button();
        btn.setGraphic(new ImageView(broncosImg));

        
        
        int x = 774;
        int y = 702;
        
        HBox hbox = new HBox();
        hbox.getChildren().add(btn);
        
        Image backgroundImage = new Image ("file:Background.png", x, y, false, false);
        ImageView bg = new ImageView();
        bg.setImage(backgroundImage);
        
    
        
        // Creates a pane to hold the image
        StackPane stackPane = new StackPane();      
        stackPane.getChildren().addAll(bg, hbox); // adds the image to the pane
        
        HBox root = new HBox();
        root.getChildren().add(stackPane);
        
        // Creates a scene and places it in the stage
        Scene scene = new Scene(root, x, y);
        primaryStage.setTitle("NFL Draft - Broncos & Cowboys Edition"); // set the stage title
        primaryStage.setScene(scene); // place the scene in the stage
        primaryStage.show(); // display the stage     
        
        // possibly array of scenes that is accessed by an event MOUSE 
    }
    
    public static void main(String[] args) {
        launch(args);
    }
}

