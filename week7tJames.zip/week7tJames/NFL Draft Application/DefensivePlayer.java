package NFLDraft;

/** Program: Creates defensive players
 * File: Player.java
 * Summary: Creates an option to choose defensive player
 * Author: Tim James
 * Date: November 11, 2017
 */
public class DefensivePlayer extends Player {
        
        int sackStats; // amount of sacks 
        int stfStats; // amount of stuffs
        int astStats; // amount of assisted tackles
    
        public DefensivePlayer() {}
        
        public DefensivePlayer(int sackStatsIn, int stfStatsIn, int astStatsIn) {
            
        sackStats = sackStatsIn; // assigns the value of sackStatsIn to the sackStats class instance variable
        stfStats = stfStatsIn; // assigns the value of stfStatsIn to the stfStats class instance variable
        astStats = astStatsIn; // assigns the value of astStatsIn to the astStats class instance variable
        }
    
        public void setSackStats(int sackStatsIn) {
            this.sackStats = sackStatsIn; // set instance variable sackStats to sackStats passed in the method
        }
    
            public int getSackStats() {
                return sackStats; // get the value of the instance variable sackStats
            }
    
            public void setStfStats(int stfStatsIn) {
                this.stfStats = stfStatsIn; // set instance variable stfStats to stfStats passed in the method
            }
    
            public int getStfStats() {
                return stfStats; // get the value of the instance variable stfStats
            }
    
            public void setAstStats(int astStatsIn) {
                this.astStats = astStatsIn; // set instance variable astStats to astStats passed in the method
            }
    
            public int getAstStats() {
                return astStats; // get the value of the instance variable astStats
            }
            
            public void displayOffensivePlayerInfo() {
            System.out.println("SACK: " + getSackStats());
            System.out.println("STF: " + getStfStats());
            System.out.println("AST: " + getAstStats());
            }
}


