package NFLDraft;

/** Program: Manager NFL Draft
 * File: Manager.java
 * Summary: creates an array for the players to be held in
 * Author: Tim James
 * Date: November 5, 2017
 */
public class Manager {
    public static void main(String[] args) { 
        final int ARRAY_LENGTH = 6; // declares the constant to set array size
        Player[ ] athlete = new Player[ARRAY_LENGTH]; // creates an array of Player objects

        // instantiate the Player class
        Player athlete1 = new Player("Kapri Bibbs", "RB", "Broncos", 29, 129, 0, 203, "5\' 11\"", 24, 35) {}; // Creates an instance of the Player class and initializes class instance variables
        Player athlete2 = new Player("Trevor Siemian", "QB", "Broncos", 86, 629, 7, 220, "6\' 3\"", 25, 13) {}; // Creates an instance of the Player class and initializes class instance variables
        Player athlete3 = new Player("Bob Marley", "TE", "Broncos", 57, 300, 2, 210, "6\' 2\"", 26, 9) {}; // Creates an instance of the Player class and initializes class instance variables
        Player athlete4 = new Player("Caleb Stanton", "WR", "Broncos", 46, 250, 3, 200, "5\' 10\"", 20, 23) {}; // Creates an instance of the Player class and initializes class instance variables
        Player athlete5 = new Player("Craig West", "LB", "Broncos", 80, 700, 0, 204, "5\' 7\"", 28, 42) {}; // Creates an instance of the Player class and initializes class instance variables
        Player athlete6 = new Player("Mary Poppins", "LB", "Broncos", 10, 610, 6, 230, "5\' 9\"", 26, 17) {}; // Creates an instance of the Player class and initializes class instance variables

        // Add the athlete objects to the array
        athlete[0] = athlete1; // adding Kapri Bibbs to the array
        athlete[1] = athlete2; // adding Trevor Siemian to the array
        athlete[2] = athlete3; // adding Bob Marley to the array
        athlete[3] = athlete4; // adding Caleb Stanton to the array
        athlete[4] = athlete5; // adding Craig West to the array
        athlete[5] = athlete6; // adding Mary Poppins to the array
        
        Player.sortByName(athlete); // sort the array by name
        
        System.out.println(); // blank line

        for (int i = 0; i < athlete.length; i++) {
            athlete[ i ].displayPlayerInfo(); // display output to the console
            System.out.println(); // blank line
        }
    } 
} 

    

