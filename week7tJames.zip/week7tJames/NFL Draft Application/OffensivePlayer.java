package NFLDraft;

/** Program: Creates offensive players
 * File: Player.java
 * Summary: Creates an option to choose offensive player
 * Author: Tim James
 * Date: November 11, 2017
 */
public class OffensivePlayer extends Player {
    
    private int attStats; // attempts of player
    private int ydsStats; // yards of player
    private int tdStats; // touchdowns of player
    
    public OffensivePlayer() {} // Player Constructor
    
    public OffensivePlayer(int attStatsIn, int ydsStatsIn, int tdStatsIn) {
    
        attStats = attStatsIn; // assigns the value of attStatsIn to the attStats class instance variable
        ydsStats = ydsStatsIn; // assigns the value of ydsStatsIn to the ydsStats class instance variable
        tdStats = tdStatsIn; // assigns the value of tdStatsIn to the tdStats class instance variable
    }
    
        public void setAttStats(int attStatsIn) {
            this.attStats = attStatsIn; // set instance variable attStats to attStats passed in the method
        }
    
            public int getAttStats() {
                return attStats; // get the value of the instance variable attStats
            }
    
            public void setYdsStats(int ydsStatsIn) {
                this.ydsStats = ydsStatsIn; // set instance variable ydsStats to ydsStats passed in the method
            }
    
            public int getYdsStats() {
                return ydsStats; // get the value of the instance variable ydsStats
            }
    
            public void setTdStats(int tdStatsIn) {
                this.tdStats = tdStatsIn; // set instance variable tdStats to tdStats passed in the method
            }
    
            public int getTdStats() {
                return tdStats; // get the value of the instance variable tdStats
            }
            
            public void displayOffensivePlayerInfo() {
            System.out.println("ATT: " + getAttStats());
            System.out.println("YDS: " + getYdsStats());
            System.out.println("TD: " + getTdStats());
            }
}
