package CheckerBoard;

/* Program: Checkerboard
 * File: Checkerboard.java
 * Summary: Creates a black and white checkerd board
 * Author: Tim James
 * Date: November 18, 2017
 */

import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;


public class Tile extends Rectangle {

    public Tile(boolean light, int x, int y) {
        setWidth(Checkerboard.TILE_SIZE);
        setHeight(Checkerboard.TILE_SIZE);
        
        relocate(x * Checkerboard.TILE_SIZE, y * Checkerboard.TILE_SIZE);
        
        setFill(light ? Color.BLACK : Color.WHITE);
    }

  
  
}
