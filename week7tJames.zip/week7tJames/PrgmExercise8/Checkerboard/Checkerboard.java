package CheckerBoard;

/* Program: Checkerboard
 * File: Checkerboard.java
 * Summary: Creates a black and white checkerd board
 * Author: Tim James
 * Date: November 18, 2017
 */

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class Checkerboard extends Application {
    
    public static final int TILE_SIZE = 100; // sets tile size
    public static final int WIDTH = 8; // sets tile width
    public static final int HEIGHT = 8; // sets tile height
    
    private Tile[][] board = new Tile[WIDTH][HEIGHT];
    
    private Group squareGroup = new Group();
    
    private Parent createContent() {
        Pane base = new Pane();
        base.setPrefSize(WIDTH * TILE_SIZE, HEIGHT * TILE_SIZE);
        base.getChildren().add(squareGroup);
        
        for (int y = 0; y < HEIGHT; y++) {
            for (int x = 0; x < WIDTH; x++) {
                Tile square = new Tile((x + y) % 2 == 0, x, y);
                board[x][y] = square;
                
                squareGroup.getChildren().add(square);
            }
        }
        
        return base;
    }
    
    @Override
    public void start(Stage primaryStage) throws Exception {
        Scene scene = new Scene(createContent());
        primaryStage.setTitle("Checker Board");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    
    public static void main(String[] args) {
        launch(args);
    }
}
