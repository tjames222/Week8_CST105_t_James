package card;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 *
 * @author timjames
 */
public class RandomCardGame extends Application {
    
   static ArrayList<Integer> deck = new ArrayList<>();
   static int[] threeCards = new int[3];
    
    @Override
    public void start(Stage primaryStage) throws Exception {
        Pane hbox = new HBox(3);
        Image card[] = new Image[threeCards.length];
        
        for (int i = 0; i < threeCards.length; i++) {   
            card[i] = new Image("file:card/" + (threeCards[i]) + ".png");
            hbox.getChildren().add(new ImageView(card[i]));
        }
        // Creates the scene
        // /Users/timjames/Desktop/card/1.png
        Scene scene = new Scene(hbox, 250, 100);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Three Random Cards");
        primaryStage.show(); 
    }
    
    public static void displayNum(int[] threeCards) {
        for (int i = 0; i < threeCards.length; i++) {
            System.out.print(threeCards[i] + " ");
        }
    }
    
    public static void three(int[] threeCards) {
        
        Random rand = new Random();
        int number;
        int index = 0;
        for (int i = 52; i > 49; i--) {
            number = rand.nextInt(i);
            threeCards[index] = deck.get(number);
            deck.remove(number);
            index++;
        }
    }
   
    public static void store52Cards() {
       for (int i = 1; i <= 52; i++)
        deck.add(i);
    }
    public static void main(String[] args) {
        store52Cards();
        Collections.shuffle(deck);
        three(threeCards);
        displayNum(threeCards);
        launch(args);
    }
    
}
